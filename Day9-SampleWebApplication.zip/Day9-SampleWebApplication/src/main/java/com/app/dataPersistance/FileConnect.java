package com.app.dataPersistance;

import com.app.dataaccess.DataAccess;
import com.app.entity.Player;

public class FileConnect implements DataAccess{

	@Override
	public int addPlayer(Player obj) {
		// write the code to add a line to csv
		return 0;
	}

	
}
