package com.app.dataPersistance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.app.dataaccess.DataAccess;
import com.app.entity.Player;

//this is the data persistance layer
public class DatabaseConnect implements DataAccess {

	public int addPlayer(Player obj)
	{
		int updateRowCount=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/javasession","root","2282001");
			
			String insert="insert into player(playerid,jersey,playername) values(?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(insert);
			pstmt.setInt(1,obj.getPlayerId());
			pstmt.setInt(2,obj.getJersey());
			pstmt.setString(3,obj.getPlayerName() );
			updateRowCount=pstmt.executeUpdate();
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return updateRowCount;
	}
}
