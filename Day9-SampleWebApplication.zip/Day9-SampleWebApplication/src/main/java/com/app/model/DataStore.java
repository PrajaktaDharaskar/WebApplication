package com.app.model;

import com.app.dataPersistance.FileConnect;
import com.app.dataaccess.DataAccess;
import com.app.entity.Player;

//this is business logic
public class DataStore {
	
	public int StoreInformation(Player obj)
	{
		DataAccess ref=new FileConnect();
			return	ref.addPlayer(obj);
	}

	public void addPlayer(Player object) {
		// TODO Auto-generated method stub
		
	}

}
