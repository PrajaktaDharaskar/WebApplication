package com.app.model.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.entity.Player;
import com.app.model.DataStore;

/**
 * Servlet implementation class PlayerServlet
 */
//this is service layer component
@WebServlet("/player")
public class PlayerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlayerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String playerid=request.getParameter("playerid");
		int pid=Integer.parseInt(playerid);
		String jersey=request.getParameter("jersey");
		int jerseyNumber=Integer.parseInt(jersey);
		String playername=request.getParameter("playername");
		Player object=new Player(pid,jerseyNumber,playername);
		DataStore ref=new DataStore();
		ref.addPlayer(object);
	}

}
