package com.app.entity;

//this is entity class - VO/POJO/DTO
//VO- Value object
//POJO-plain old java object
//DTO-data transfer object
public class Player {

	int playerId;
	int jersey;
	String playerName;
	
	public Player()
	{
		
	}
	public Player(int v1,int v2,String v3)
	{
		playerId=v1;
		jersey=v2;
		playerName=v3;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public int getJersey() {
		return jersey;
	}
	public void setJersey(int jersey) {
		this.jersey = jersey;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	
	
	
}
