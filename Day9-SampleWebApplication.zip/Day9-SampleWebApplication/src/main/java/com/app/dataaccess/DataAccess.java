package com.app.dataaccess;

import com.app.entity.Player;

//this is data access layer
public interface DataAccess {
	
	public int addPlayer(Player obj);

}
